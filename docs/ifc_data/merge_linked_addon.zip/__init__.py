# merge_linked_addon — BIM: Merge Linked IFC Files
# ============================================================
# merge_linked_addon.py
# Blender add-on — MergeLinked IFC Panel for Bonsai BIM
# ============================================================
# Single-file distribution: the ifcpatch recipe is embedded
# inside this add-on and is written to the correct recipes
# folder automatically when the add-on is enabled.
#
# Install via: Edit → Preferences → Add-ons → Install…
# Then enable "BIM: Merge Linked IFC Files"
# ============================================================

bl_info = {
    "name": "BIM: Merge Linked IFC Files",
    "author": "Custom",
    "version": (1, 1, 0),
    "blender": (5, 1, 0),
    "location": "3D Viewport → Sidebar (N) → BIM → Merge Linked IFC",
    "description": (
        "Merges linked IFC files in the active Bonsai session into one output file. "
        "The MergeLinked ifcpatch recipe is installed automatically on first enable."
    ),
    "category": "BIM",
}

import os
import sys
import json
import shutil
import importlib

import bpy
from bpy.props import (
    BoolProperty,
    StringProperty,
    CollectionProperty,
    PointerProperty,
)
from bpy.types import PropertyGroup, Operator, Panel

# ─────────────────────────────────────────────────────────────
# Embedded recipe source
# The recipe code is stored here as a string and written to the
# ifcpatch recipes folder when the add-on is enabled.
# ─────────────────────────────────────────────────────────────

_RECIPE_NAME = "MergeLinked.py"
_RECIPE_SOURCE = '"""\nifcpatch recipe: MergeLinked\n============================\nMerges all (or selected) IFC files that are linked in the current Bonsai\nsession into a single output IFC file.\n\nFeatures\n--------\n* Lists every file currently linked via Scene Properties → IFC Links.\n* Checkbox selection of which linked files to include.\n* Optional checkbox to also include the memory-loaded (active) IFC project.\n* Optional "Use Temporary Incremental Merge" mode:\n  - Creates a  <output_dir>/merge_linked_tmp/  folder.\n  - Merges file[0] + file[1] → tmp_step_001.ifc\n  - tmp_step_001.ifc + file[2] → tmp_step_002.ifc  … and so on.\n  - The final step file is copied to the real output path.\n  - The tmp folder is kept for debugging.\n\nUsage (Python / CLI)\n--------------------\n    import ifcpatch, ifcopenshell\n\n    model = ifcopenshell.open("base.ifc")\n    result = ifcpatch.execute({\n        "input": "base.ifc",\n        "file": model,\n        "recipe": "MergeLinked",\n        "arguments": [\n            # filepaths  – list of IFC paths to merge (JSON array as string,\n            #               OR plain list when calling from Python directly)\n            \'["path/to/linked_a.ifc", "path/to/linked_b.ifc"]\',\n            # include_active – "true"/"false"  include the memory-loaded file\n            "false",\n            # use_incremental – "true"/"false"\n            "true",\n        ],\n    })\n    result.write("merged_output.ifc")\n\nBonsai UI\n---------\nThe recipe is surfaced through the standard IfcPatch panel\n(Scene Properties → IFC Patch → Recipe: MergeLinked).\n\nThe Bonsai operator for this recipe (see operator.py / ui.py notes at the\nbottom of this file) should:\n  1. Read  bpy.context.scene.BIMProjectProperties.ifc_links  to populate\n     the file list in the panel.\n  2. Pass the selected paths as the "filepaths" argument.\n"""\n\nfrom __future__ import annotations\n\nimport json\nimport logging\nimport os\nimport shutil\nfrom typing import Sequence, Union\n\nimport ifcopenshell\nimport ifcopenshell.util.element\n\n# ---------------------------------------------------------------------------\n# Optional Bonsai / bpy import (only present when running inside Blender)\n# ---------------------------------------------------------------------------\ntry:\n    import bpy  # type: ignore\n    from bonsai.bim.ifc import IfcStore  # type: ignore\n    _IN_BLENDER = True\nexcept ImportError:\n    _IN_BLENDER = False\n\n\nlog = logging.getLogger(__name__)\n\n\n# ---------------------------------------------------------------------------\n# Helper: collect linked file paths from the Bonsai scene\n# ---------------------------------------------------------------------------\ndef get_linked_ifc_paths() -> list[str]:\n    """Return the file paths of all IFC files currently linked in Bonsai.\n\n    In Bonsai the links live at::\n\n        bpy.context.scene.BIMProjectProperties.ifc_links[i].name\n\n    where ``name`` stores the absolute path to the linked ``.ifc`` file.\n    """\n    if not _IN_BLENDER:\n        return []\n    try:\n        props = bpy.context.scene.BIMProjectProperties\n        return [link.name for link in props.ifc_links if link.name]\n    except Exception as exc:  # pragma: no cover\n        log.warning("Could not read ifc_links from Bonsai: %s", exc)\n        return []\n\n\ndef get_active_ifc_path() -> str | None:\n    """Return the file path of the currently loaded (memory) IFC project."""\n    if not _IN_BLENDER:\n        return None\n    try:\n        return bpy.context.scene.BIMProperties.ifc_file or None\n    except Exception:\n        return None\n\n\n# ---------------------------------------------------------------------------\n# Core patcher class  – follows the ifcpatch BasePatcher interface\n# ---------------------------------------------------------------------------\nclass Patcher:\n    """Merge all linked IFC files into one.\n\n    Parameters\n    ----------\n    file:\n        The base IFC model (already loaded by ifcpatch).  When\n        *include_active* is ``True`` this file is included first in the\n        merge sequence.\n    logger:\n        Standard Python logger injected by ifcpatch.\n    filepaths:\n        Sequence of IFC file paths to merge.  Accepts:\n\n        * A Python list/tuple of strings.\n        * A single JSON-encoded string ``\'["a.ifc","b.ifc"]\'``.\n        * A comma-separated string ``"a.ifc,b.ifc"``.\n\n        If running inside Blender **and** the list is empty, the recipe\n        falls back to reading the linked files from the active Bonsai scene.\n    include_active:\n        When ``True`` the in-memory loaded IFC project is prepended to the\n        merge list so it is included in the output.  Default ``False``.\n    use_incremental:\n        When ``True`` an incremental (step-by-step) merge is performed via\n        a temporary folder next to the output file.  Each intermediate result\n        is saved as ``tmp_step_NNN.ifc``.  The folder is kept after the\n        recipe finishes.  Default ``False``.\n    output_path:\n        Destination path for the final merged file.  Required when\n        *use_incremental* is ``True`` so the tmp folder can be placed beside\n        it.  When omitted the incremental strategy writes steps to the\n        system temp directory.\n    """\n\n    # ------------------------------------------------------------------\n    # ifcpatch wires these up before calling patch()\n    # ------------------------------------------------------------------\n    file: ifcopenshell.file\n    logger: logging.Logger | None\n\n    # ------------------------------------------------------------------\n    # Recipe-specific parameters (set via __init__ or ifcpatch arguments)\n    # ------------------------------------------------------------------\n    filepaths: list[str] = []\n    include_active: bool = False\n    use_incremental: bool = False\n    output_path: str = ""\n\n    # ------------------------------------------------------------------\n\n    def __init__(\n        self,\n        file: ifcopenshell.file,\n        logger: logging.Logger | None = None,\n        filepaths: Sequence[Union[str, ifcopenshell.file]] = (),\n        include_active: bool | str = False,\n        use_incremental: bool | str = False,\n        output_path: str = "",\n    ) -> None:\n        self.file = file\n        self.logger = logger or logging.getLogger(__name__)\n\n        # ---- normalise filepaths argument --------------------------------\n        resolved: list[str] = []\n        if filepaths:\n            # Handle a single JSON/CSV string arriving from CLI arguments\n            if isinstance(filepaths, str):\n                filepaths_str: str = filepaths\n                stripped = filepaths_str.strip()\n                if stripped.startswith("["):\n                    resolved = [p for p in json.loads(stripped) if p]\n                else:\n                    resolved = [p.strip() for p in stripped.split(",") if p.strip()]\n            else:\n                for fp in filepaths:\n                    if isinstance(fp, str) and fp:\n                        # Still might be a JSON list if the caller packed it\n                        stripped = fp.strip()\n                        if stripped.startswith("["):\n                            resolved.extend(\n                                p for p in json.loads(stripped) if p\n                            )\n                        else:\n                            resolved.append(stripped)\n                    # ifcopenshell.file instances are handled later via merge()\n\n        # Fall back to Bonsai linked files when nothing was provided\n        if not resolved and _IN_BLENDER:\n            resolved = get_linked_ifc_paths()\n            self.logger.info(\n                "MergeLinked: auto-detected %d linked file(s) from Bonsai scene.",\n                len(resolved),\n            )\n\n        self.filepaths = resolved\n\n        # ---- normalise boolean flags (may arrive as strings from CLI) ----\n        self.include_active = _to_bool(include_active)\n        self.use_incremental = _to_bool(use_incremental)\n        self.output_path = output_path or ""\n\n    # ------------------------------------------------------------------\n    # Public entry point called by ifcpatch\n    # ------------------------------------------------------------------\n    def patch(self) -> None:\n        if not self.filepaths:\n            self.logger.warning(\n                "MergeLinked: no files to merge.  "\n                "Either link IFC files in Bonsai or supply the \'filepaths\' argument."\n            )\n            return\n\n        # Optionally prepend the active in-memory file\n        active_path: str | None = None\n        if self.include_active and _IN_BLENDER:\n            active_path = get_active_ifc_path()\n            if active_path:\n                self.logger.info(\n                    "MergeLinked: including active project: %s", active_path\n                )\n            else:\n                self.logger.warning(\n                    "MergeLinked: include_active=True but no active IFC path found."\n                )\n\n        if self.use_incremental:\n            self._incremental_merge(active_path)\n        else:\n            self._direct_merge(active_path)\n\n    # ------------------------------------------------------------------\n    # Strategy A: direct merge into self.file (standard behaviour)\n    # ------------------------------------------------------------------\n    def _direct_merge(self, active_path: str | None) -> None:\n        """Merge all files directly into *self.file* in one pass."""\n        all_paths = self._build_path_list(active_path)\n        self.logger.info(\n            "MergeLinked (direct): merging %d file(s) into base model.",\n            len(all_paths),\n        )\n        for path in all_paths:\n            self.logger.info("  → merging: %s", path)\n            try:\n                other = ifcopenshell.open(path)\n                self._merge_into(self.file, other)\n            except Exception as exc:\n                self.logger.error("  ✗ failed to merge %s: %s", path, exc)\n\n        self.logger.info("MergeLinked (direct): done.")\n\n    # ------------------------------------------------------------------\n    # Strategy B: incremental merge via a temp folder\n    # ------------------------------------------------------------------\n    def _incremental_merge(self, active_path: str | None) -> None:\n        """Merge files one-by-one through a temp folder.\n\n        Step 0 : base = first file (self.file, or active, or filepaths[0])\n        Step N : base = merge(base, filepaths[N])\n        Final  : self.file ← last step result\n                 Copy last step file → output_path  (if output_path set)\n                 Keep tmp folder for debugging.\n        """\n        all_paths = self._build_path_list(active_path)\n        if not all_paths:\n            self.logger.warning("MergeLinked (incremental): path list is empty.")\n            return\n\n        # ------ create tmp folder ----------------------------------------\n        tmp_dir = self._make_tmp_dir()\n        self.logger.info(\n            "MergeLinked (incremental): tmp folder → %s", tmp_dir\n        )\n        self.logger.info(\n            "MergeLinked (incremental): %d file(s) to merge.", len(all_paths)\n        )\n\n        # ------ step 0: save initial base to tmp -------------------------\n        # The initial base is self.file (the file passed to ifcpatch as input).\n        # We write it to tmp so every step operates on files on disk.\n        step_path = os.path.join(tmp_dir, "tmp_step_000.ifc")\n        self.file.write(step_path)\n        self.logger.info("  step 000 (base) saved: %s", step_path)\n\n        # ------ iterate over all files to merge --------------------------\n        for idx, path in enumerate(all_paths, start=1):\n            next_step = os.path.join(tmp_dir, f"tmp_step_{idx:03d}.ifc")\n            self.logger.info(\n                "  step %03d: merging \'%s\' into previous step …", idx, path\n            )\n            try:\n                base_model = ifcopenshell.open(step_path)\n                other_model = ifcopenshell.open(path)\n                self._merge_into(base_model, other_model)\n                base_model.write(next_step)\n                self.logger.info("  step %03d saved: %s", idx, next_step)\n                step_path = next_step          # advance cursor\n            except Exception as exc:\n                self.logger.error(\n                    "  ✗ step %03d failed (%s): %s – skipping.", idx, path, exc\n                )\n                # step_path stays at the last successful step\n\n        # ------ load final result into self.file -------------------------\n        final_model = ifcopenshell.open(step_path)\n        # Reload self.file contents from the final merged model.\n        # ifcpatch will call file.write() after patch() returns, so we\n        # swap the underlying file object by patching the instance in-place.\n        self._reload_file_from(final_model)\n\n        # ------ optionally copy to declared output path ------------------\n        if self.output_path:\n            try:\n                shutil.copy2(step_path, self.output_path)\n                self.logger.info(\n                    "MergeLinked (incremental): final file copied to %s",\n                    self.output_path,\n                )\n            except Exception as exc:\n                self.logger.error(\n                    "MergeLinked (incremental): could not copy to output path: %s",\n                    exc,\n                )\n\n        self.logger.info(\n            "MergeLinked (incremental): done. Tmp folder kept at: %s", tmp_dir\n        )\n\n    # ------------------------------------------------------------------\n    # Low-level merge helper  (mirrors MergeProjects.Patcher.merge)\n    # ------------------------------------------------------------------\n    def _merge_into(\n        self,\n        base: ifcopenshell.file,\n        other: ifcopenshell.file,\n    ) -> None:\n        """Merge *other* into *base*, reusing geometric contexts and\n        converting length units automatically."""\n\n        # -- unit conversion ----------------------------------------------\n        base_unit = _get_unit_name(base)\n        other_unit = _get_unit_name(other)\n        if base_unit != other_unit:\n            self.logger.info(\n                "    unit mismatch (%s vs %s) – converting second model.",\n                other_unit, base_unit,\n            )\n            import ifcpatch  # available inside Blender / ifcpatch env\n            other = ifcpatch.execute(\n                {\n                    "input": "input.ifc",\n                    "file": other,\n                    "recipe": "ConvertLengthUnit",\n                    "arguments": [base_unit],\n                }\n            )\n\n        # -- find the project element in each file ------------------------\n        base_project = base.by_type("IfcProject")[0]\n        other_project = other.by_type("IfcProject")[0]\n\n        # -- copy all entities from other into base -----------------------\n        added: dict[int, ifcopenshell.entity_instance] = {}\n\n        for entity in other:\n            # Skip the IfcProject from the second file; we reuse the first\'s\n            if entity == other_project:\n                continue\n            try:\n                added_entity = base.add(entity)\n                added[entity.id()] = added_entity\n            except Exception:\n                pass  # already added or schema mismatch\n\n        # -- re-attach aggregates of other\'s project to base project ------\n        for rel in other.by_type("IfcRelAggregates"):\n            if rel.RelatingObject == other_project:\n                # The relating object should become base_project\n                if rel.id() in added:\n                    added[rel.id()].RelatingObject = base_project\n\n        # -- reuse equivalent existing geometric contexts -----------------\n        self._reuse_existing_contexts(base, other, added)\n\n    # ------------------------------------------------------------------\n\n    def _reuse_existing_contexts(\n        self,\n        base: ifcopenshell.file,\n        other: ifcopenshell.file,\n        added: dict[int, ifcopenshell.entity_instance],\n    ) -> None:\n        """Replace added representation contexts with equivalent existing ones\n        from *base* to avoid duplicate Model / Plan contexts."""\n        for entity in other.by_type("IfcGeometricRepresentationContext"):\n            if entity.id() not in added:\n                continue\n            added_ctx = added[entity.id()]\n            existing = _get_equivalent_context(base, entity)\n            if existing and existing != added_ctx:\n                for inverse in base.get_inverse(added_ctx):\n                    try:\n                        ifcopenshell.util.element.replace_attribute(\n                            inverse, added_ctx, existing\n                        )\n                    except Exception:\n                        pass\n                try:\n                    base.remove(added_ctx)\n                except Exception:\n                    pass\n\n    # ------------------------------------------------------------------\n    # Utilities\n    # ------------------------------------------------------------------\n\n    def _build_path_list(self, active_path: str | None) -> list[str]:\n        """Return ordered list of paths to merge into the base model."""\n        paths = list(self.filepaths)\n        # If include_active, prepend the active file BEFORE the linked ones\n        if active_path and active_path not in paths:\n            paths.insert(0, active_path)\n        return paths\n\n    def _make_tmp_dir(self) -> str:\n        """Create and return the path to the incremental temp folder."""\n        if self.output_path:\n            parent = os.path.dirname(os.path.abspath(self.output_path))\n        else:\n            import tempfile\n            parent = tempfile.gettempdir()\n\n        tmp_dir = os.path.join(parent, "merge_linked_tmp")\n        os.makedirs(tmp_dir, exist_ok=True)\n        return tmp_dir\n\n    def _reload_file_from(self, source: ifcopenshell.file) -> None:\n        """Copy the contents of *source* into *self.file* in-place so that\n        ifcpatch\'s caller receives the merged result via the original object."""\n        # Remove all existing entities from self.file\n        to_remove = list(self.file)\n        for ent in to_remove:\n            try:\n                self.file.remove(ent)\n            except Exception:\n                pass\n        # Add all entities from the final merged model\n        for ent in source:\n            try:\n                self.file.add(ent)\n            except Exception:\n                pass\n\n\n# ---------------------------------------------------------------------------\n# Module-level helpers\n# ---------------------------------------------------------------------------\n\ndef _to_bool(value: bool | str) -> bool:\n    if isinstance(value, bool):\n        return value\n    return str(value).strip().lower() in ("true", "1", "yes")\n\n\ndef _get_unit_name(ifc_file: ifcopenshell.file) -> str:\n    """Return the length unit name (e.g. \'METRE\', \'MILLIMETRE\') of *ifc_file*."""\n    try:\n        for unit in ifc_file.by_type("IfcSIUnit"):\n            if unit.UnitType == "LENGTHUNIT":\n                prefix = (unit.Prefix or "").upper()\n                name = (unit.Name or "").upper()\n                return f"{prefix}{name}".strip() or "METRE"\n    except Exception:\n        pass\n    return "METRE"\n\n\ndef _get_equivalent_context(\n    base: ifcopenshell.file,\n    added_ctx: ifcopenshell.entity_instance,\n) -> ifcopenshell.entity_instance | None:\n    """Find a context in *base* that matches *added_ctx* by ContextType /\n    ContextIdentifier / TargetView."""\n    try:\n        ctx_type = getattr(added_ctx, "ContextType", None)\n        ctx_id = getattr(added_ctx, "ContextIdentifier", None)\n        target_view = getattr(added_ctx, "TargetView", None)\n    except Exception:\n        return None\n\n    for existing in base.by_type("IfcGeometricRepresentationContext"):\n        if (\n            getattr(existing, "ContextType", None) == ctx_type\n            and getattr(existing, "ContextIdentifier", None) == ctx_id\n            and getattr(existing, "TargetView", None) == target_view\n        ):\n            return existing\n    return None\n\n\n# ===========================================================================\n# Bonsai UI integration notes\n# ===========================================================================\n#\n# To expose this recipe in the Bonsai IfcPatch panel with a file checklist,\n# add the following to the relevant Bonsai UI / operator files:\n#\n# ---- bonsai/bim/module/patch/ui.py  (inside draw_ifcpatch_ui or similar) --\n#\n#   if props.recipe == "MergeLinked":\n#       col = layout.column(align=True)\n#       col.label(text="Linked IFC Files:")\n#       ifc_links = context.scene.BIMProjectProperties.ifc_links\n#       if not ifc_links:\n#           col.label(text="  (no linked files found)", icon="INFO")\n#       else:\n#           for i, link in enumerate(ifc_links):\n#               row = col.row()\n#               row.prop(\n#                   context.scene.MergeLinkedProperties,\n#                   f"link_{i}_selected",\n#                   text=os.path.basename(link.name),\n#               )\n#       col.separator()\n#       col.prop(\n#           context.scene.MergeLinkedProperties,\n#           "include_active",\n#           text="Include memory-loaded project",\n#       )\n#       col.prop(\n#           context.scene.MergeLinkedProperties,\n#           "use_incremental",\n#           text="Use temporary incremental merge",\n#       )\n#\n# ---- bonsai/bim/module/patch/operator.py  (execute method) ---------------\n#\n#   ml_props = context.scene.MergeLinkedProperties\n#   ifc_links = context.scene.BIMProjectProperties.ifc_links\n#   selected_paths = [\n#       link.name\n#       for i, link in enumerate(ifc_links)\n#       if getattr(ml_props, f"link_{i}_selected", True)\n#   ]\n#   bpy.ops.bim.execute_ifc_patch(\n#       recipe="MergeLinked",\n#       arguments=json.dumps([\n#           json.dumps(selected_paths),       # filepaths\n#           str(ml_props.include_active).lower(),\n#           str(ml_props.use_incremental).lower(),\n#           bpy.path.abspath(props.output_file),  # output_path\n#       ]),\n#   )\n#\n# ---- Register a PropertyGroup for the checkboxes -------------------------\n#\n#   class MergeLinkedProperties(bpy.types.PropertyGroup):\n#       include_active: bpy.props.BoolProperty(name="Include Active", default=False)\n#       use_incremental: bpy.props.BoolProperty(name="Incremental Merge", default=False)\n#       # Dynamically generated per-link bools are added at registration time\n#       # by iterating over ifc_links and calling bpy.utils.register_class again,\n#       # or by using a CollectionProperty with a selected BoolProperty.\n#\n#   bpy.utils.register_class(MergeLinkedProperties)\n#   bpy.types.Scene.MergeLinkedProperties = bpy.props.PointerProperty(\n#       type=MergeLinkedProperties\n#   )\n#\n# ===========================================================================\n'


# ─────────────────────────────────────────────────────────────
# Recipe installation helpers
# ─────────────────────────────────────────────────────────────

def _find_ifcpatch_recipes_dir():
    """Locate the ifcpatch/recipes directory inside Blender's Python environment.

    Searches sys.path for a site-packages directory that contains ifcpatch.
    Returns the path string, or None if not found.
    """
    for p in sys.path:
        candidate = os.path.join(p, "ifcpatch", "recipes")
        if os.path.isdir(candidate):
            return candidate
    return None


def _recipe_dest_path():
    """Return the full destination path for MergeLinked.py, or None."""
    d = _find_ifcpatch_recipes_dir()
    return os.path.join(d, _RECIPE_NAME) if d else None


def _install_recipe():
    """Write the embedded recipe to the ifcpatch recipes folder.

    Returns (success: bool, message: str).
    """
    dest = _recipe_dest_path()
    if dest is None:
        return False, (
            "Could not locate the ifcpatch/recipes folder. "
            "Make sure Bonsai is installed and enabled."
        )
    try:
        os.makedirs(os.path.dirname(dest), exist_ok=True)
        with open(dest, "w", encoding="utf-8") as fh:
            fh.write(_RECIPE_SOURCE)
        # Force Python to re-scan so the new module is importable immediately
        import importlib
        if "ifcpatch.recipes.MergeLinked" in sys.modules:
            del sys.modules["ifcpatch.recipes.MergeLinked"]
        if "ifcpatch.recipes" in sys.modules:
            importlib.reload(sys.modules["ifcpatch.recipes"])
        return True, f"Recipe installed to: {dest}"
    except Exception as exc:
        return False, f"Failed to write recipe: {exc}"


def _recipe_is_installed():
    """Return True if MergeLinked.py exists in the recipes folder."""
    dest = _recipe_dest_path()
    return dest is not None and os.path.isfile(dest)


def _recipe_is_importable():
    """Return True if ifcpatch can import the recipe module."""
    try:
        import ifcpatch.recipes.MergeLinked  # noqa: F401
        return True
    except ImportError:
        return False


def _bonsai_available():
    try:
        import bonsai  # noqa: F401
        return True
    except ImportError:
        return False


# ─────────────────────────────────────────────────────────────
# Install recipe at module import time so it appears in
# Bonsai's recipe dropdown on the next Blender startup.
# (Bonsai scans for recipes when the module is first imported,
#  so we must write the file before that scan happens.)
# ─────────────────────────────────────────────────────────────
try:
    _recipe_was_missing = not _recipe_is_importable()
    _early_ok, _early_msg = _install_recipe()
    print(f"[MergeLinked] Early install: {_early_msg}")
except Exception as _early_exc:
    _recipe_was_missing = False
    print(f"[MergeLinked] Early install failed: {_early_exc}")


# ─────────────────────────────────────────────────────────────
# Bonsai scene helpers
# ─────────────────────────────────────────────────────────────

def _get_bonsai_linked_paths(context):
    """
    Read linked IFC file paths from Bonsai.
    Confirmed: BIMProjectProperties.links, each item has .filepath attribute.
    """
    # Primary: BIMProjectProperties.links[*].filepath  (confirmed)
    try:
        links = context.scene.BIMProjectProperties.links
        found = []
        for lnk in links:
            p = getattr(lnk, "filepath", None)
            if p and isinstance(p, str) and p.strip():
                found.append(p.strip())
        if found:
            return found
    except Exception as e:
        print(f"[MergeLinked] links.filepath failed: {e}")

    # Fallback: IfcStore.session_files
    try:
        from bonsai.bim.ifc import IfcStore
        if hasattr(IfcStore, "session_files") and IfcStore.session_files:
            active = getattr(IfcStore, "path", None)
            found = [p.strip() for p in IfcStore.session_files.keys()
                     if p and p.strip() != active]
            if found:
                return found
    except Exception as e:
        print(f"[MergeLinked] session_files fallback failed: {e}")

    return []




def _get_active_ifc_path(context):
    try:
        return context.scene.BIMProperties.ifc_file or ""
    except Exception:
        return ""


# ─────────────────────────────────────────────────────────────
# PropertyGroups
# ─────────────────────────────────────────────────────────────

class MERGELINKED_LinkedFileItem(PropertyGroup):
    filepath: StringProperty(name="Path")
    selected: BoolProperty(name="Include", default=True)


class MERGELINKED_Props(PropertyGroup):
    linked_files: CollectionProperty(type=MERGELINKED_LinkedFileItem)
    include_active: BoolProperty(
        name="Include loaded project",
        description="Also include the IFC project currently open in Bonsai",
        default=False,
    )
    use_incremental: BoolProperty(
        name="Use temporary incremental merge",
        description=(
            "Merge files one at a time and save each step to a temp folder "
            "next to the output file"
        ),
        default=False,
    )
    output_path: StringProperty(
        name="Output IFC",
        description="Destination path for the merged IFC file",
        subtype="FILE_PATH",
        default="",
    )
    recipe_status: StringProperty(default="")


# ─────────────────────────────────────────────────────────────
# Operators
# ─────────────────────────────────────────────────────────────

class MERGELINKED_OT_install_recipe(Operator):
    """Write the embedded MergeLinked recipe to the ifcpatch recipes folder."""
    bl_idname = "mergelinked.install_recipe"
    bl_label = "Install Recipe"
    bl_description = "Copy the MergeLinked ifcpatch recipe into the correct folder"

    def execute(self, context):
        ok, msg = _install_recipe()
        level = {"INFO"} if ok else {"ERROR"}
        self.report(level, msg)
        context.scene.MergeLinkedProps.recipe_status = "OK" if ok else "FAIL"
        return {"FINISHED"} if ok else {"CANCELLED"}


class MERGELINKED_OT_refresh_links(Operator):
    """Re-read the IFC Links list from the active Bonsai scene."""
    bl_idname = "mergelinked.refresh_links"
    bl_label = "Refresh"
    bl_description = "Reload the linked IFC file list from the active Bonsai scene"

    def execute(self, context):
        props = context.scene.MergeLinkedProps
        paths = _get_bonsai_linked_paths(context)
        prev = {item.filepath: item.selected for item in props.linked_files}
        props.linked_files.clear()
        for p in paths:
            item = props.linked_files.add()
            item.filepath = p
            item.selected = prev.get(p, True)
        self.report({"INFO"}, f"Found {len(paths)} linked IFC file(s).")
        return {"FINISHED"}


class MERGELINKED_OT_select_all(Operator):
    bl_idname = "mergelinked.select_all"
    bl_label = "All"
    def execute(self, context):
        for item in context.scene.MergeLinkedProps.linked_files:
            item.selected = True
        return {"FINISHED"}


class MERGELINKED_OT_deselect_all(Operator):
    bl_idname = "mergelinked.deselect_all"
    bl_label = "None"
    def execute(self, context):
        for item in context.scene.MergeLinkedProps.linked_files:
            item.selected = False
        return {"FINISHED"}


class MERGELINKED_OT_run(Operator):
    """Execute the MergeLinked recipe with the current settings."""
    bl_idname = "mergelinked.run"
    bl_label = "Merge IFC Files"
    bl_description = "Run the MergeLinked ifcpatch recipe"

    def execute(self, context):
        if not _bonsai_available():
            self.report({"ERROR"}, "Bonsai is not installed or not enabled.")
            return {"CANCELLED"}

        # Auto-install recipe if missing
        if not _recipe_is_importable():
            ok, msg = _install_recipe()
            if not ok:
                self.report({"ERROR"}, f"Recipe not available: {msg}")
                return {"CANCELLED"}
            self.report({"INFO"}, f"Recipe auto-installed: {msg}")

        props = context.scene.MergeLinkedProps

        selected_paths = [
            item.filepath for item in props.linked_files
            if item.selected and item.filepath
        ]

        if not selected_paths and not props.include_active:
            self.report({"WARNING"}, "No files selected.")
            return {"CANCELLED"}

        output = bpy.path.abspath(props.output_path).strip()
        if not output:
            self.report({"ERROR"}, "Set an output IFC file path first.")
            return {"CANCELLED"}

        output_dir = os.path.dirname(output)
        if output_dir:
            os.makedirs(output_dir, exist_ok=True)

        import ifcopenshell
        import ifcpatch

        active_path = _get_active_ifc_path(context)

        if props.include_active and active_path:
            base_path = active_path
            extra_paths = selected_paths
        elif selected_paths:
            base_path = selected_paths[0]
            extra_paths = selected_paths[1:]
        else:
            self.report({"ERROR"}, "Nothing to merge.")
            return {"CANCELLED"}

        try:
            base_model = ifcopenshell.open(base_path)
        except Exception as exc:
            self.report({"ERROR"}, f"Could not open base model: {exc}")
            return {"CANCELLED"}

        total = len(extra_paths) + 1
        self.report({"INFO"}, f"Merging {total} IFC file(s)…")

        try:
            result = ifcpatch.execute({
                "input": base_path,
                "file": base_model,
                "recipe": "MergeLinked",
                "arguments": [
                    json.dumps(extra_paths),
                    "false",
                    str(props.use_incremental).lower(),
                    output,
                ],
            })
        except Exception as exc:
            self.report({"ERROR"}, f"Merge failed: {exc}")
            return {"CANCELLED"}

        try:
            result.write(output)
        except Exception as exc:
            self.report({"ERROR"}, f"Could not write output: {exc}")
            return {"CANCELLED"}

        self.report({"INFO"}, f"✓ Merged IFC saved to: {output}")

        if props.use_incremental:
            tmp_dir = os.path.join(output_dir, "merge_linked_tmp")
            self.report({"INFO"}, f"Temp folder kept at: {tmp_dir}")

        return {"FINISHED"}


# ─────────────────────────────────────────────────────────────
# Panel
# ─────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────
# Panels — integrated into Bonsai's Scene Properties patch area
# ─────────────────────────────────────────────────────────────

# ─────────────────────────────────────────────────────────────
# Draw injection — appends our UI into Bonsai's BIM_PT_patch
# panel draw function at register time, no subclassing needed.
# ─────────────────────────────────────────────────────────────

def _draw_merge_linked_appended(self, context):
    """Injected into BIM_PT_patch.draw — only draws when MergeLinked selected."""
    # Always show restart banner if needed, regardless of selected recipe
    if _needs_restart():
        layout = self.layout
        box = layout.box()
        col = box.column(align=True)
        col.alert = True
        col.label(text="Restart Blender to use MergeLinked!", icon="ERROR")
        col.operator("mergelinked.restart_blender", icon="FILE_REFRESH")
        return
    try:
        recipe = context.scene.BIMPatchProperties.ifc_patch_recipes
    except Exception:
        return
    if recipe != "MergeLinked":
        return
    _draw_merge_linked_ui(self.layout, context)



# ─────────────────────────────────────────────────────────────
# Restart helpers
# ─────────────────────────────────────────────────────────────

def _needs_restart():
    """True if the recipe was just written this session and Bonsai
    hasn't scanned it yet (it won't appear in the dropdown until restart)."""
    try:
        # If MergeLinked is already in Bonsai's recipe enum it's fine
        props = bpy.context.scene.BIMPatchProperties
        items = props.bl_rna.properties["ifc_patch_recipes"].enum_items
        return not any(i.identifier == "MergeLinked" for i in items)
    except Exception:
        return False


class MERGELINKED_OT_restart(bpy.types.Operator):
    """Save preferences and restart Blender."""
    bl_idname = "mergelinked.restart_blender"
    bl_label = "Save & Restart Blender"
    bl_description = "Save user preferences and restart Blender so MergeLinked appears in the recipe list"

    def execute(self, context):
        bpy.ops.wm.save_userpref()
        bpy.ops.wm.quit_blender()
        return {"FINISHED"}


_classes = [
    MERGELINKED_LinkedFileItem,
    MERGELINKED_OT_restart,
    MERGELINKED_Props,
    MERGELINKED_OT_install_recipe,
    MERGELINKED_OT_refresh_links,
    MERGELINKED_OT_select_all,
    MERGELINKED_OT_deselect_all,
    MERGELINKED_OT_run,
]


# ─────────────────────────────────────────────────────────────
# Panel injection helpers
# ─────────────────────────────────────────────────────────────

_injected_panel_class = None  # tracks which class we appended to


def _find_patch_panel_class():
    """Discover Bonsai's IFC Patch panel class at runtime."""
    try:
        from bonsai.bim.module.patch import ui as patch_ui
        # Try known names first
        for name in ("BIM_PT_patch", "BIM_PT_ifcpatch", "BIM_PT_patches"):
            cls = getattr(patch_ui, name, None)
            if cls is not None:
                return cls
        # Fallback: scan the module for any Panel with "patch" in the label
        import inspect
        import bpy
        for _, obj in inspect.getmembers(patch_ui, inspect.isclass):
            if issubclass(obj, bpy.types.Panel):
                label = getattr(obj, "bl_label", "").lower()
                idname = getattr(obj, "bl_idname", "").lower()
                if "patch" in label or "patch" in idname:
                    return obj
    except Exception as e:
        print(f"[MergeLinked] _find_patch_panel_class error: {e}")
    return None


def _inject_draw():
    global _injected_panel_class
    cls = _find_patch_panel_class()
    if cls is not None:
        cls.append(_draw_merge_linked_appended)
        _injected_panel_class = cls
        print(f"[MergeLinked] Injected draw into {cls.__name__}")
    else:
        print("[MergeLinked] WARNING: Could not find Bonsai patch panel class to inject into.")
        print("[MergeLinked] Run this in Blender's Python console to find the class name:")
        print("  from bonsai.bim.module.patch import ui; print(dir(ui))")


def _uninject_draw():
    global _injected_panel_class
    if _injected_panel_class is not None:
        try:
            _injected_panel_class.remove(_draw_merge_linked_appended)
            print(f"[MergeLinked] Removed draw from {_injected_panel_class.__name__}")
        except Exception as e:
            print(f"[MergeLinked] Could not remove draw: {e}")
        _injected_panel_class = None


def _uninstall_recipe():
    """Remove MergeLinked.py from the ifcpatch recipes folder."""
    dest = _recipe_dest_path()
    if dest and os.path.isfile(dest):
        try:
            os.remove(dest)
            # Flush module cache
            import sys
            for key in list(sys.modules.keys()):
                if "MergeLinked" in key:
                    del sys.modules[key]
            print(f"[MergeLinked] Recipe removed: {dest}")
        except Exception as e:
            print(f"[MergeLinked] Could not remove recipe: {e}")


def register():
    for cls in _classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.MergeLinkedProps = PointerProperty(type=MERGELINKED_Props)

    # Inject our draw function into Bonsai's patch panel
    _inject_draw()

    # Auto-install the recipe silently on enable if Bonsai is present
    if _bonsai_available() and not _recipe_is_importable():
        ok, msg = _install_recipe()
        if ok:
            print(f"[MergeLinked] Recipe installed automatically: {msg}")
        else:
            print(f"[MergeLinked] Could not auto-install recipe: {msg}")


def unregister():
    # Remove our injected draw function
    _uninject_draw()

    # Note: recipe file is kept in ifcpatch/recipes/ intentionally.
    # Removing it here would make it disappear from the dropdown
    # whenever the addon is disabled. Delete MergeLinked.py manually
    # from the recipes folder if you want a full clean uninstall.

    for cls in reversed(_classes):
        bpy.utils.unregister_class(cls)
    try:
        del bpy.types.Scene.MergeLinkedProps
    except AttributeError:
        pass


if __name__ == "__main__":
    register()
