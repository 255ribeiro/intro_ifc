"""
ifcpatch recipe: MergeLinked
============================
Merges all (or selected) IFC files that are linked in the current Bonsai
session into a single output IFC file.

Features
--------
* Lists every file currently linked via Scene Properties → IFC Links.
* Checkbox selection of which linked files to include.
* Optional checkbox to also include the memory-loaded (active) IFC project.
* Optional "Use Temporary Incremental Merge" mode:
  - Creates a  <output_dir>/merge_linked_tmp/  folder.
  - Merges file[0] + file[1] → tmp_step_001.ifc
  - tmp_step_001.ifc + file[2] → tmp_step_002.ifc  … and so on.
  - The final step file is copied to the real output path.
  - The tmp folder is kept for debugging.

Usage (Python / CLI)
--------------------
    import ifcpatch, ifcopenshell

    model = ifcopenshell.open("base.ifc")
    result = ifcpatch.execute({
        "input": "base.ifc",
        "file": model,
        "recipe": "MergeLinked",
        "arguments": [
            # filepaths  – list of IFC paths to merge (JSON array as string,
            #               OR plain list when calling from Python directly)
            '["path/to/linked_a.ifc", "path/to/linked_b.ifc"]',
            # include_active – "true"/"false"  include the memory-loaded file
            "false",
            # use_incremental – "true"/"false"
            "true",
        ],
    })
    result.write("merged_output.ifc")

Bonsai UI
---------
The recipe is surfaced through the standard IfcPatch panel
(Scene Properties → IFC Patch → Recipe: MergeLinked).

The Bonsai operator for this recipe (see operator.py / ui.py notes at the
bottom of this file) should:
  1. Read  bpy.context.scene.BIMProjectProperties.ifc_links  to populate
     the file list in the panel.
  2. Pass the selected paths as the "filepaths" argument.
"""

from __future__ import annotations

import json
import logging
import os
import shutil
from typing import Sequence, Union

import ifcopenshell
import ifcopenshell.util.element

# ---------------------------------------------------------------------------
# Optional Bonsai / bpy import (only present when running inside Blender)
# ---------------------------------------------------------------------------
try:
    import bpy  # type: ignore
    from bonsai.bim.ifc import IfcStore  # type: ignore
    _IN_BLENDER = True
except ImportError:
    _IN_BLENDER = False


log = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Helper: collect linked file paths from the Bonsai scene
# ---------------------------------------------------------------------------
def get_linked_ifc_paths() -> list[str]:
    """Return the file paths of all IFC files currently linked in Bonsai.

    In Bonsai the links live at::

        bpy.context.scene.BIMProjectProperties.ifc_links[i].name

    where ``name`` stores the absolute path to the linked ``.ifc`` file.
    """
    if not _IN_BLENDER:
        return []
    try:
        props = bpy.context.scene.BIMProjectProperties
        return [link.name for link in props.ifc_links if link.name]
    except Exception as exc:  # pragma: no cover
        log.warning("Could not read ifc_links from Bonsai: %s", exc)
        return []


def get_active_ifc_path() -> str | None:
    """Return the file path of the currently loaded (memory) IFC project."""
    if not _IN_BLENDER:
        return None
    try:
        return bpy.context.scene.BIMProperties.ifc_file or None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# Core patcher class  – follows the ifcpatch BasePatcher interface
# ---------------------------------------------------------------------------
class Patcher:
    """Merge all linked IFC files into one.

    Parameters
    ----------
    file:
        The base IFC model (already loaded by ifcpatch).  When
        *include_active* is ``True`` this file is included first in the
        merge sequence.
    logger:
        Standard Python logger injected by ifcpatch.
    filepaths:
        Sequence of IFC file paths to merge.  Accepts:

        * A Python list/tuple of strings.
        * A single JSON-encoded string ``'["a.ifc","b.ifc"]'``.
        * A comma-separated string ``"a.ifc,b.ifc"``.

        If running inside Blender **and** the list is empty, the recipe
        falls back to reading the linked files from the active Bonsai scene.
    include_active:
        When ``True`` the in-memory loaded IFC project is prepended to the
        merge list so it is included in the output.  Default ``False``.
    use_incremental:
        When ``True`` an incremental (step-by-step) merge is performed via
        a temporary folder next to the output file.  Each intermediate result
        is saved as ``tmp_step_NNN.ifc``.  The folder is kept after the
        recipe finishes.  Default ``False``.
    output_path:
        Destination path for the final merged file.  Required when
        *use_incremental* is ``True`` so the tmp folder can be placed beside
        it.  When omitted the incremental strategy writes steps to the
        system temp directory.
    """

    # ------------------------------------------------------------------
    # ifcpatch wires these up before calling patch()
    # ------------------------------------------------------------------
    file: ifcopenshell.file
    logger: logging.Logger | None

    # ------------------------------------------------------------------
    # Recipe-specific parameters (set via __init__ or ifcpatch arguments)
    # ------------------------------------------------------------------
    filepaths: list[str] = []
    include_active: bool = False
    use_incremental: bool = False
    output_path: str = ""

    # ------------------------------------------------------------------

    def __init__(
        self,
        file: ifcopenshell.file,
        logger: logging.Logger | None = None,
        filepaths: Sequence[Union[str, ifcopenshell.file]] = (),
        include_active: bool | str = False,
        use_incremental: bool | str = False,
        output_path: str = "",
    ) -> None:
        self.file = file
        self.logger = logger or logging.getLogger(__name__)

        # ---- normalise filepaths argument --------------------------------
        resolved: list[str] = []
        if filepaths:
            # Handle a single JSON/CSV string arriving from CLI arguments
            if isinstance(filepaths, str):
                filepaths_str: str = filepaths
                stripped = filepaths_str.strip()
                if stripped.startswith("["):
                    resolved = [p for p in json.loads(stripped) if p]
                else:
                    resolved = [p.strip() for p in stripped.split(",") if p.strip()]
            else:
                for fp in filepaths:
                    if isinstance(fp, str) and fp:
                        # Still might be a JSON list if the caller packed it
                        stripped = fp.strip()
                        if stripped.startswith("["):
                            resolved.extend(
                                p for p in json.loads(stripped) if p
                            )
                        else:
                            resolved.append(stripped)
                    # ifcopenshell.file instances are handled later via merge()

        # Fall back to Bonsai linked files when nothing was provided
        if not resolved and _IN_BLENDER:
            resolved = get_linked_ifc_paths()
            self.logger.info(
                "MergeLinked: auto-detected %d linked file(s) from Bonsai scene.",
                len(resolved),
            )

        self.filepaths = resolved

        # ---- normalise boolean flags (may arrive as strings from CLI) ----
        self.include_active = _to_bool(include_active)
        self.use_incremental = _to_bool(use_incremental)
        self.output_path = output_path or ""

    # ------------------------------------------------------------------
    # Public entry point called by ifcpatch
    # ------------------------------------------------------------------
    def patch(self) -> None:
        if not self.filepaths:
            self.logger.warning(
                "MergeLinked: no files to merge.  "
                "Either link IFC files in Bonsai or supply the 'filepaths' argument."
            )
            return

        # Optionally prepend the active in-memory file
        active_path: str | None = None
        if self.include_active and _IN_BLENDER:
            active_path = get_active_ifc_path()
            if active_path:
                self.logger.info(
                    "MergeLinked: including active project: %s", active_path
                )
            else:
                self.logger.warning(
                    "MergeLinked: include_active=True but no active IFC path found."
                )

        if self.use_incremental:
            self._incremental_merge(active_path)
        else:
            self._direct_merge(active_path)

    # ------------------------------------------------------------------
    # Strategy A: direct merge into self.file (standard behaviour)
    # ------------------------------------------------------------------
    def _direct_merge(self, active_path: str | None) -> None:
        """Merge all files directly into *self.file* in one pass."""
        all_paths = self._build_path_list(active_path)
        self.logger.info(
            "MergeLinked (direct): merging %d file(s) into base model.",
            len(all_paths),
        )
        for path in all_paths:
            self.logger.info("  → merging: %s", path)
            try:
                other = ifcopenshell.open(path)
                self._merge_into(self.file, other)
            except Exception as exc:
                self.logger.error("  ✗ failed to merge %s: %s", path, exc)

        self.logger.info("MergeLinked (direct): done.")

    # ------------------------------------------------------------------
    # Strategy B: incremental merge via a temp folder
    # ------------------------------------------------------------------
    def _incremental_merge(self, active_path: str | None) -> None:
        """Merge files one-by-one through a temp folder.

        Step 0 : base = first file (self.file, or active, or filepaths[0])
        Step N : base = merge(base, filepaths[N])
        Final  : self.file ← last step result
                 Copy last step file → output_path  (if output_path set)
                 Keep tmp folder for debugging.
        """
        all_paths = self._build_path_list(active_path)
        if not all_paths:
            self.logger.warning("MergeLinked (incremental): path list is empty.")
            return

        # ------ create tmp folder ----------------------------------------
        tmp_dir = self._make_tmp_dir()
        self.logger.info(
            "MergeLinked (incremental): tmp folder → %s", tmp_dir
        )
        self.logger.info(
            "MergeLinked (incremental): %d file(s) to merge.", len(all_paths)
        )

        # ------ step 0: save initial base to tmp -------------------------
        # The initial base is self.file (the file passed to ifcpatch as input).
        # We write it to tmp so every step operates on files on disk.
        step_path = os.path.join(tmp_dir, "tmp_step_000.ifc")
        self.file.write(step_path)
        self.logger.info("  step 000 (base) saved: %s", step_path)

        # ------ iterate over all files to merge --------------------------
        for idx, path in enumerate(all_paths, start=1):
            next_step = os.path.join(tmp_dir, f"tmp_step_{idx:03d}.ifc")
            self.logger.info(
                "  step %03d: merging '%s' into previous step …", idx, path
            )
            try:
                base_model = ifcopenshell.open(step_path)
                other_model = ifcopenshell.open(path)
                self._merge_into(base_model, other_model)
                base_model.write(next_step)
                self.logger.info("  step %03d saved: %s", idx, next_step)
                step_path = next_step          # advance cursor
            except Exception as exc:
                self.logger.error(
                    "  ✗ step %03d failed (%s): %s – skipping.", idx, path, exc
                )
                # step_path stays at the last successful step

        # ------ load final result into self.file -------------------------
        final_model = ifcopenshell.open(step_path)
        # Reload self.file contents from the final merged model.
        # ifcpatch will call file.write() after patch() returns, so we
        # swap the underlying file object by patching the instance in-place.
        self._reload_file_from(final_model)

        # ------ optionally copy to declared output path ------------------
        if self.output_path:
            try:
                shutil.copy2(step_path, self.output_path)
                self.logger.info(
                    "MergeLinked (incremental): final file copied to %s",
                    self.output_path,
                )
            except Exception as exc:
                self.logger.error(
                    "MergeLinked (incremental): could not copy to output path: %s",
                    exc,
                )

        self.logger.info(
            "MergeLinked (incremental): done. Tmp folder kept at: %s", tmp_dir
        )

    # ------------------------------------------------------------------
    # Low-level merge helper  (mirrors MergeProjects.Patcher.merge)
    # ------------------------------------------------------------------
    def _merge_into(
        self,
        base: ifcopenshell.file,
        other: ifcopenshell.file,
    ) -> None:
        """Merge *other* into *base*, reusing geometric contexts and
        converting length units automatically."""

        # -- unit conversion ----------------------------------------------
        base_unit = _get_unit_name(base)
        other_unit = _get_unit_name(other)
        if base_unit != other_unit:
            self.logger.info(
                "    unit mismatch (%s vs %s) – converting second model.",
                other_unit, base_unit,
            )
            import ifcpatch  # available inside Blender / ifcpatch env
            other = ifcpatch.execute(
                {
                    "input": "input.ifc",
                    "file": other,
                    "recipe": "ConvertLengthUnit",
                    "arguments": [base_unit],
                }
            )

        # -- find the project element in each file ------------------------
        base_project = base.by_type("IfcProject")[0]
        other_project = other.by_type("IfcProject")[0]

        # -- copy all entities from other into base -----------------------
        added: dict[int, ifcopenshell.entity_instance] = {}

        for entity in other:
            # Skip the IfcProject from the second file; we reuse the first's
            if entity == other_project:
                continue
            try:
                added_entity = base.add(entity)
                added[entity.id()] = added_entity
            except Exception:
                pass  # already added or schema mismatch

        # -- re-attach aggregates of other's project to base project ------
        for rel in other.by_type("IfcRelAggregates"):
            if rel.RelatingObject == other_project:
                # The relating object should become base_project
                if rel.id() in added:
                    added[rel.id()].RelatingObject = base_project

        # -- reuse equivalent existing geometric contexts -----------------
        self._reuse_existing_contexts(base, other, added)

    # ------------------------------------------------------------------

    def _reuse_existing_contexts(
        self,
        base: ifcopenshell.file,
        other: ifcopenshell.file,
        added: dict[int, ifcopenshell.entity_instance],
    ) -> None:
        """Replace added representation contexts with equivalent existing ones
        from *base* to avoid duplicate Model / Plan contexts."""
        for entity in other.by_type("IfcGeometricRepresentationContext"):
            if entity.id() not in added:
                continue
            added_ctx = added[entity.id()]
            existing = _get_equivalent_context(base, entity)
            if existing and existing != added_ctx:
                for inverse in base.get_inverse(added_ctx):
                    try:
                        ifcopenshell.util.element.replace_attribute(
                            inverse, added_ctx, existing
                        )
                    except Exception:
                        pass
                try:
                    base.remove(added_ctx)
                except Exception:
                    pass

    # ------------------------------------------------------------------
    # Utilities
    # ------------------------------------------------------------------

    def _build_path_list(self, active_path: str | None) -> list[str]:
        """Return ordered list of paths to merge into the base model."""
        paths = list(self.filepaths)
        # If include_active, prepend the active file BEFORE the linked ones
        if active_path and active_path not in paths:
            paths.insert(0, active_path)
        return paths

    def _make_tmp_dir(self) -> str:
        """Create and return the path to the incremental temp folder."""
        if self.output_path:
            parent = os.path.dirname(os.path.abspath(self.output_path))
        else:
            import tempfile
            parent = tempfile.gettempdir()

        tmp_dir = os.path.join(parent, "merge_linked_tmp")
        os.makedirs(tmp_dir, exist_ok=True)
        return tmp_dir

    def _reload_file_from(self, source: ifcopenshell.file) -> None:
        """Copy the contents of *source* into *self.file* in-place so that
        ifcpatch's caller receives the merged result via the original object."""
        # Remove all existing entities from self.file
        to_remove = list(self.file)
        for ent in to_remove:
            try:
                self.file.remove(ent)
            except Exception:
                pass
        # Add all entities from the final merged model
        for ent in source:
            try:
                self.file.add(ent)
            except Exception:
                pass


# ---------------------------------------------------------------------------
# Module-level helpers
# ---------------------------------------------------------------------------

def _to_bool(value: bool | str) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("true", "1", "yes")


def _get_unit_name(ifc_file: ifcopenshell.file) -> str:
    """Return the length unit name (e.g. 'METRE', 'MILLIMETRE') of *ifc_file*."""
    try:
        for unit in ifc_file.by_type("IfcSIUnit"):
            if unit.UnitType == "LENGTHUNIT":
                prefix = (unit.Prefix or "").upper()
                name = (unit.Name or "").upper()
                return f"{prefix}{name}".strip() or "METRE"
    except Exception:
        pass
    return "METRE"


def _get_equivalent_context(
    base: ifcopenshell.file,
    added_ctx: ifcopenshell.entity_instance,
) -> ifcopenshell.entity_instance | None:
    """Find a context in *base* that matches *added_ctx* by ContextType /
    ContextIdentifier / TargetView."""
    try:
        ctx_type = getattr(added_ctx, "ContextType", None)
        ctx_id = getattr(added_ctx, "ContextIdentifier", None)
        target_view = getattr(added_ctx, "TargetView", None)
    except Exception:
        return None

    for existing in base.by_type("IfcGeometricRepresentationContext"):
        if (
            getattr(existing, "ContextType", None) == ctx_type
            and getattr(existing, "ContextIdentifier", None) == ctx_id
            and getattr(existing, "TargetView", None) == target_view
        ):
            return existing
    return None


# ===========================================================================
# Bonsai UI integration notes
# ===========================================================================
#
# To expose this recipe in the Bonsai IfcPatch panel with a file checklist,
# add the following to the relevant Bonsai UI / operator files:
#
# ---- bonsai/bim/module/patch/ui.py  (inside draw_ifcpatch_ui or similar) --
#
#   if props.recipe == "MergeLinked":
#       col = layout.column(align=True)
#       col.label(text="Linked IFC Files:")
#       ifc_links = context.scene.BIMProjectProperties.ifc_links
#       if not ifc_links:
#           col.label(text="  (no linked files found)", icon="INFO")
#       else:
#           for i, link in enumerate(ifc_links):
#               row = col.row()
#               row.prop(
#                   context.scene.MergeLinkedProperties,
#                   f"link_{i}_selected",
#                   text=os.path.basename(link.name),
#               )
#       col.separator()
#       col.prop(
#           context.scene.MergeLinkedProperties,
#           "include_active",
#           text="Include memory-loaded project",
#       )
#       col.prop(
#           context.scene.MergeLinkedProperties,
#           "use_incremental",
#           text="Use temporary incremental merge",
#       )
#
# ---- bonsai/bim/module/patch/operator.py  (execute method) ---------------
#
#   ml_props = context.scene.MergeLinkedProperties
#   ifc_links = context.scene.BIMProjectProperties.ifc_links
#   selected_paths = [
#       link.name
#       for i, link in enumerate(ifc_links)
#       if getattr(ml_props, f"link_{i}_selected", True)
#   ]
#   bpy.ops.bim.execute_ifc_patch(
#       recipe="MergeLinked",
#       arguments=json.dumps([
#           json.dumps(selected_paths),       # filepaths
#           str(ml_props.include_active).lower(),
#           str(ml_props.use_incremental).lower(),
#           bpy.path.abspath(props.output_file),  # output_path
#       ]),
#   )
#
# ---- Register a PropertyGroup for the checkboxes -------------------------
#
#   class MergeLinkedProperties(bpy.types.PropertyGroup):
#       include_active: bpy.props.BoolProperty(name="Include Active", default=False)
#       use_incremental: bpy.props.BoolProperty(name="Incremental Merge", default=False)
#       # Dynamically generated per-link bools are added at registration time
#       # by iterating over ifc_links and calling bpy.utils.register_class again,
#       # or by using a CollectionProperty with a selected BoolProperty.
#
#   bpy.utils.register_class(MergeLinkedProperties)
#   bpy.types.Scene.MergeLinkedProperties = bpy.props.PointerProperty(
#       type=MergeLinkedProperties
#   )
#
# ===========================================================================
