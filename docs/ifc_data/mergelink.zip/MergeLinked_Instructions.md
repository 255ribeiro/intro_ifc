# MergeLinked — IFC Federation Merge Tool for Bonsai BIM

Merge linked IFC files in your Bonsai session into one federated output — with a checkbox UI and zero manual configuration.

📥 [Download merge_linked_addon.zip](./merge_linked_addon.zip) — **the only file you need**

> The ifcpatch recipe (`MergeLinked.py`) is embedded inside the add-on zip
> and installed automatically the first time you enable it.

---

## Requirements

| | Version |
|---|---|
| Blender | 5.1 (compatible with 4.2+) |
| Bonsai (BlenderBIM) | 0.8.5 or later |

---

## Installation

### Step 1 — Install the add-on zip

Blender 5.1 uses the new Extensions system. There are two equally valid ways to install:

**Option A — Drag and drop (easiest)**
Drag `merge_linked_addon.zip` directly from Windows Explorer and drop it onto the Blender window.

**Option B — Install from Preferences**
1. Go to **Edit → Preferences → Add-ons**.
2. Click the **⌄ dropdown arrow** in the top-right corner.
3. Choose **Install from Disk…**
4. Browse to and select `merge_linked_addon.zip`.

### Step 2 — Enable the add-on

After installing, tick the checkbox next to **BIM: Merge Linked IFC Files** to enable it.

On enable, the add-on silently writes the `MergeLinked.py` recipe into the
correct ifcpatch recipes folder automatically. Nothing else to do.

> **Where does the recipe go?**
> ```
> %APPDATA%\Blender Foundation\Blender\5.1\extensions\.local\lib\python3.13\site-packages\ifcpatch\recipes\MergeLinked.py
> ```
> The panel shows the install status and the exact path.

---

## Using the tool

### 1 — Open the panel

In the **3D Viewport**, press **N** → **BIM** tab → **Merge Linked IFC**.

### 2 — Link your IFC files in Bonsai

If you haven't already, add your discipline files via:

**Scene Properties → IFC Project Setup → IFC Links → Link IFC**

### 3 — Refresh the file list

Click **Refresh** in the panel. All linked files appear as a checklist, ticked by default.

### 4 — Configure options

| Option | Description |
|---|---|
| **Include loaded project** | Also merge the IFC file currently open in Bonsai |
| **Use temporary incremental merge** | Merge one file at a time, saving each step to a `merge_linked_tmp/` folder for debugging |

### 5 — Set the output path

Enter the destination `.ifc` file path in the **Output File** field.

### 6 — Merge

Click **Merge N IFC Files**.

---

## What's inside the zip

```
merge_linked_addon.zip
  ├── blender_manifest.toml   ← Blender 4.2+ extension metadata
  └── __init__.py             ← add-on code + embedded recipe
```

The recipe (`MergeLinked.py`) is embedded as a string inside `__init__.py`
and written to disk automatically on first enable.

---

## Incremental merge mode

```
merge_linked_tmp\
  tmp_step_000.ifc   ← base model
  tmp_step_001.ifc   ← base + structural.ifc
  tmp_step_002.ifc   ← step_001 + mep.ifc
  ...
→ merged_output.ifc  ← copy of final step
```

The temp folder sits next to your output file and is kept after the merge for debugging. Delete it manually when done.

---

## Troubleshooting

**"Bonsai not found" shown in the panel**
Install and enable Bonsai before this add-on.

**"Recipe: not installed" even after enabling**
The panel will show an **Install Recipe** button — click it once. This can happen if Bonsai was not yet enabled when this add-on first loaded.

**No files in the checklist after Refresh**
Add links first: Scene Properties → IFC Links → Link IFC.

**Drag and drop does nothing**
Make sure you're dropping onto the main Blender window (not onto a dialog). Alternatively use Option B (Install from Disk).

**Merged file has duplicate sites or buildings**
Expected — the merge combines `IfcProject` elements but does not unify the spatial hierarchy. Use `MergeDuplicateTypes` afterward or reassign containment manually in Bonsai.

---

*Built on IfcOpenShell / Bonsai — https://ifcopenshell.org*
